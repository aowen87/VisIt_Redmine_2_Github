#!/usr/bin/env python3
import sys, string
print(sys.version)
b = string.find("sentence", "s")
print(b)


