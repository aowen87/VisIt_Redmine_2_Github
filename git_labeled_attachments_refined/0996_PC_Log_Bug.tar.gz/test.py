OpenDatabase("./fig3.bov")
AddPlot("Pseudocolor", "val")
pc = PseudocolorAttributes()
pc.lightingFlag = 0
pc.minFlag = 1
pc.maxFlag = 1
pc.min = 1e-22
pc.max = 10
pc.colorTableName = "calewhite"
pc.scaling = pc.Log
SetPlotOptions(pc)
DrawPlots()

