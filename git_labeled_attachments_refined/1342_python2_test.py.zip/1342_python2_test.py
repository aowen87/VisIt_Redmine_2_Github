#!/usr/bin/env python2
import sys, string
print sys.version
b = string.find("sentence", "s")
print b
 

