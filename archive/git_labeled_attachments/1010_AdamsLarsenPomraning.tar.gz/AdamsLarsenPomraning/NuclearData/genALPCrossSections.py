# Append to python's search path.
import sys
fudgePath = "/usr/apps/fudge/old"
import os
os.environ["FUDGEPATH"] = fudgePath
sys.path.insert(0, fudgePath)
sys.path.insert(0, fudgePath+"/Src")

from fudge import *

# Use a large atomic mass to get isotropic scattering.
LargeMass = 1.0e+8

# Specify the isotope ZAs.
material0ZA = 6012
material1ZA = 92238
material0ZAAtomicMass  = LargeMass # 12.0      # [g/mole]
material0ZAMassDensity = 1.6       # [g/cm^3]
material1ZAAtomicMass  = LargeMass # 238.0508  # [g/mole]
material1ZAMassDensity = 18.9      # [g/cm^3]

# Set the desired macroscopic cross section values.
# Material 0.
macroscopicSigmaTMaterial0 = 10.0/99.0   # [1/cm]
scatteringRatioMaterial0   = 0.9
# Material 1.
macroscopicSigmaTMaterial1 = 100.0/11.0  # [1/cm]
scatteringRatioMaterial1   = 0.9

# The number density for each isotope.
avogadrosNumber = 6.02214179e+23  # [#/mole]
material0ZANumberDensity = material0ZAMassDensity*avogadrosNumber/material0ZAAtomicMass  # [#/cm^3]
material1ZANumberDensity = material1ZAMassDensity*avogadrosNumber/material1ZAAtomicMass  # [#/cm^3]
cmSquaredPerBarn = 1.0e-24

# Set the desired microscopic cross section values.
# Material 0.
sigmaTMaterial0 = (macroscopicSigmaTMaterial0/material0ZANumberDensity)/cmSquaredPerBarn  # [barns]
sigmaSMaterial0 = scatteringRatioMaterial0*sigmaTMaterial0                                # [barns]
sigmaAMaterial0 = sigmaTMaterial0 - sigmaSMaterial0                                       # [barns]
# Material 1.
sigmaTMaterial1 = (macroscopicSigmaTMaterial1/material1ZANumberDensity)/cmSquaredPerBarn  # [barns]
sigmaSMaterial1 = scatteringRatioMaterial0*sigmaTMaterial1                                # [barns]
sigmaAMaterial1 = sigmaTMaterial1 - sigmaSMaterial1                                       # [barns]

print "Material 0: ZA= %5d  ND= %g  SigmaT= %g  sigmaT= %g  sigmaS= %g" % (material0ZA,
                                                                           material0ZANumberDensity,
                                                                           macroscopicSigmaTMaterial0,
                                                                           sigmaTMaterial0,
                                                                           sigmaSMaterial0)
print "Material 1: ZA= %5d  ND= %g  SigmaT= %g  sigmaT= %g  sigmaS= %g" % (material1ZA,
                                                                           material1ZANumberDensity,
                                                                           macroscopicSigmaTMaterial1,
                                                                           sigmaTMaterial1,
                                                                           sigmaSMaterial1)

# Create a bdfls object, get data from the default location,
# and save the data into the current directory.
b = bdfls.bdfls("bdfls")
b.setZAMass(material0ZA, LargeMass)
b.setZAMass(material1ZA, LargeMass)
b.save()

# Set min/max neutron energy.
nEMin = 1.0e-10  # minimum neutron energy
nEMax = 20.0     # maximum neutron energy
gEMin = 1.0e-10  # minimum gamma energy
gEMax = 20.0     # maximum gamma energy

# Create an endl project with yi = 1.
p = endlProject(yi=1)
zaMaterial0 = p.addZA(material0ZA)
zaMaterial1 = p.addZA(material1ZA)

### Material0 ###
 
# Elastic scattering data (C=10)
if sigmaSMaterial0 > 0.0:
    #                                                   y0,  C, I, S
    elasticCrossSectionMaterial0 = zaMaterial0.addFile( 0, 10, 0, 0)  # I = 0 is E, cross-section file
    elasticCrossSectionDataMaterial0 = sigmaSMaterial0*endl2dmathmisc.flattop2d(nEMin, nEMax)
    elasticCrossSectionMaterial0.addData(data=elasticCrossSectionDataMaterial0)
    
    #                                                   y0,  C, I, S
    elasticEuPMaterial0         = zaMaterial0.addFile( 1, 10, 1, 0)  # I = 1 is E, u, probability file
    elasticEuPDataListMaterial0 = [ (nEMin, -1.0, 0.5),
                                    (nEMin,  1.0, 0.5),
                                    (nEMax, -1.0, 0.5),
                                    (nEMax,  1.0, 0.5) ]
    elasticEuPDataMaterial0 = endlmisc.translate3dData(elasticEuPDataListMaterial0)
    elasticEuPMaterial0.addData(data=elasticEuPDataMaterial0)
    
# Capture data (C=46)
if sigmaAMaterial0 > 0.0:
    #                                                   y0,  C, I, S
    captureCrossSectionMaterial0 = zaMaterial0.addFile( 0, 46, 0, 0)  # I = 0 is E, cross-section file
    captureCrossSectionDataMaterial0 = sigmaAMaterial0*endl2dmathmisc.flattop2d(nEMin, nEMax)
    captureCrossSectionMaterial0.addData(data=captureCrossSectionDataMaterial0)
    
    #                                            y0,  C, I, S
    captureEEplCMaterial0 = zaMaterial0.addFile( 7, 46, 4, 0)  # I = 4 is E, E', l-order, Legendre coefficient file
    captureEEplCDataListMaterial0 = [ (0, nEMin, gEMin, 1.0/(gEMax - gEMin)),
                                      (0, nEMin, gEMax, 1.0/(gEMax - gEMin)),
                                      (0, nEMax, gEMin, 1.0/(gEMax - gEMin)),
                                      (0, nEMax, gEMax, 1.0/(gEMax - gEMin)) ]
    captureEEplCDataMaterial0 = endlmisc.translate4dData(captureEEplCDataListMaterial0)
    captureEEplCMaterial0.addData(data=captureEEplCDataMaterial0)
    
    #                                         y0,  C, I, S
    captureEMMaterial0 = zaMaterial0.addFile( 7, 46, 9, 0)  # I = 9 is E, multiplicity file
    captureEMDataMaterial0 = endl2dmathmisc.flattop2d(gEMin, gEMax)
    captureEMMaterial0.addData(data=captureEMDataMaterial0)

### Material1 ###
 
# Elastic scattering data (C=10)
if sigmaSMaterial1 > 0.0:
    #                                                   y0,  C, I, S
    elasticCrossSectionMaterial1 = zaMaterial1.addFile( 0, 10, 0, 0)  # I = 0 is E, cross-section file
    elasticCrossSectionDataMaterial1 = sigmaSMaterial1*endl2dmathmisc.flattop2d(nEMin, nEMax)
    elasticCrossSectionMaterial1.addData(data=elasticCrossSectionDataMaterial1)
    
    #                                                   y0,  C, I, S
    elasticEuPMaterial1         = zaMaterial1.addFile( 1, 10, 1, 0)  # I = 1 is E, u, probability file
    elasticEuPDataListMaterial1 = [ (nEMin, -1.0, 0.5),
                                    (nEMin,  1.0, 0.5),
                                    (nEMax, -1.0, 0.5),
                                    (nEMax,  1.0, 0.5) ]
    elasticEuPDataMaterial1 = endlmisc.translate3dData(elasticEuPDataListMaterial1)
    elasticEuPMaterial1.addData(data=elasticEuPDataMaterial1)
    
# Capture data (C=46)
if sigmaAMaterial1 > 0.0:
    #                                                   y0,  C, I, S
    captureCrossSectionMaterial1 = zaMaterial1.addFile( 0, 46, 0, 0)  # I = 0 is E, cross-section file
    captureCrossSectionDataMaterial1 = sigmaAMaterial1*endl2dmathmisc.flattop2d(nEMin, nEMax)
    captureCrossSectionMaterial1.addData(data=captureCrossSectionDataMaterial1)
    
    #                                            y0,  C, I, S
    captureEEplCMaterial1 = zaMaterial1.addFile( 7, 46, 4, 0)  # I = 4 is E, E', l-order, Legendre coefficient file
    captureEEplCDataListMaterial1 = [ (0, nEMin, gEMin, 1.0/(gEMax - gEMin)),
                                      (0, nEMin, gEMax, 1.0/(gEMax - gEMin)),
                                      (0, nEMax, gEMin, 1.0/(gEMax - gEMin)),
                                      (0, nEMax, gEMax, 1.0/(gEMax - gEMin)) ]
    captureEEplCDataMaterial1 = endlmisc.translate4dData(captureEEplCDataListMaterial1)
    captureEEplCMaterial1.addData(data=captureEEplCDataMaterial1)
    
    #                                         y0,  C, I, S
    captureEMMaterial1 = zaMaterial1.addFile( 7, 46, 9, 0)  # I = 9 is E, multiplicity file
    captureEMDataMaterial1 = endl2dmathmisc.flattop2d(gEMin, gEMax)
    captureEMMaterial1.addData(data=captureEMDataMaterial1)

# Generate the new mcf file.
p.saveProcess("/usr/gapps/data/nuclear/endl_official/endl99/mcf/mcf1.pdb", "mcf1.pdb.new", options="-no_u -i -v")
